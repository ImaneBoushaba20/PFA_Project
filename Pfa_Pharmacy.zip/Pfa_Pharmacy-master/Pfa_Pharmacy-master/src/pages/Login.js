import {useState, useRef} from 'react'
import {Link} from 'react-router-dom'
import Login from '../features/user/Login'

function ExternalPage(){


    return(
        <div className="">
                <Login />
        </div>
    )
}

export default ExternalPage